/*
 * MCP23008
 *
 * ***************************************************************************
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 ***************************************************************************
 *
 * This version of GPL is at http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 *
 ***************************************************************************
 *
 * version 1.0 / paulvha / May 2016
 *  initial version of sample program
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include "bcm2835.h"
#include <stdint.h>
//#include <getopt.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>

/* display color */
#define REDSTR "\e[1;31m%s\e[00m"
#define GRNSTR "\e[1;92m%s\e[00m"
#define YLWSTR "\e[1;93m%s\e[00m"
#define BLUSTR "\e[1;34m%s\e[00m"

/* MCP23008 registers */
#define IODIR   0
#define IPOL    1
#define GPINTEN 2
#define DEFVAL  3
#define INTCON  4
#define IOCON   5
#define GPPU    6
#define INTF    7
#define INTCAP  8
#define GPIO    9
#define OLAT    0xa

#define MCP_READ    1
#define MCP_WRITE   0
#define MAX_LEN     32
char buf[MAX_LEN];

/* MCP23008 slave address */
uint8_t slave_address_base = 0x20;

/* BSC speed*/
uint16_t bsc_div = BCM2835_I2C_CLOCK_DIVIDER_2500;

/* reset_pin on Raspbery*/
int reset_gpio = 22;

/* read interrupt from MCP23008 in Raspberry */
int int_gpio = 11;

/* PID of child process handling interrupt from MCP23008 */
pid_t   ch_pid=0;

/* set the MCP23008 slave address
 * @param sl_addr : if 0 new address will be asked
 */

int set_slave(uint8_t sl_addr)
{
    char    buf[40];
    int     addr, lp;

    if (sl_addr > 0)
    {
        if((sl_addr < 0x20) || (sl_addr > 0x27)){
            sprintf(buf,"invalid slave address provided : %x\n", sl_addr);
            printf(REDSTR, buf);
            return(1);
        }

        slave_address_base = sl_addr;

    }
    else
    {
        sprintf(buf, "current slave address set to : %x\n", slave_address_base);
        printf(GRNSTR, buf);

        lp=0;
        do
        {
            printf(YLWSTR,"provide new slave address (99 = return) ");
            scanf("%x",&addr);

            if (addr == 0x99) return(0);

            if((addr < 0x20) || (addr > 0x27))
            {
                sprintf(buf,"invalid slave address provided : %x\n", addr);
                printf(REDSTR, buf);
            }
            else
            {
                slave_address_base = addr;
                lp=1;
            }
        } while( lp == 0);
    }

    // set slave address
    bcm2835_i2c_setSlaveAddress(slave_address_base);

    // display only interactive mode
    if (sl_addr == 0){
        sprintf(buf,"Slave address set to %x\n", slave_address_base);
        printf(GRNSTR, buf);
    }

    return(0);
}

/* set/update reset pin */
int set_reset(int pp)
{
    int tmp=30;

    if (pp > 0)
    {
        if (pp > 28)
        {
            sprintf(buf,"Invalid GPIO for reset: %d\n", pp);
            printf(REDSTR, buf);
            return(1);
        }

        else
            reset_gpio = pp;
    }
    else
    {
        sprintf(buf,"current GPIO for reset is %d\n", reset_gpio);
        printf(GRNSTR, buf);
        do
        {
            printf(YLWSTR,"what is the number GPIO for reset? (99 = return) ");
            scanf("%d",&tmp);

            if (tmp == 99) return(0);

            if (tmp > 28)
            {
                printf(REDSTR, "Invalid entry. must be  low than 28. Try again\n");
            }
        } while (tmp > 28);

        reset_gpio = tmp;

    }
    // set as output
    bcm2835_gpio_fsel(reset_gpio, BCM2835_GPIO_FSEL_OUTP);

    // perform a reset
    bcm2835_gpio_write(reset_gpio, LOW);
    bcm2835_delay(500);

    bcm2835_gpio_write(reset_gpio, HIGH);
    bcm2835_delay(500);

    // only in interactive mode display
    if (pp == 0)
    {
        sprintf(buf,"GPIO for now reset is %d\n", reset_gpio);
        printf(GRNSTR, buf);
    }

    return(0);
}

/* set the MCP23008 divider */
int set_divider(uint16_t divider)
{
    char    buf[40];
    int     div, lp;

    if (divider > 0)
    {
        if( (divider == BCM2835_I2C_CLOCK_DIVIDER_2500)|| // 100Khz
            (divider == BCM2835_I2C_CLOCK_DIVIDER_626) || // 400Khz
            (divider == BCM2835_I2C_CLOCK_DIVIDER_150))   // 1.7Mhz

            bsc_div=divider;

        else
        {
            sprintf(buf,"Invalid divider value : %d\n", divider);
            printf(REDSTR, buf);
            return(1);
        }
    }
    else
    {
        if (bsc_div == BCM2835_I2C_CLOCK_DIVIDER_2500)     // 100Khz
            sprintf(buf, "current speed is 100kHz\n");
        else if (bsc_div == BCM2835_I2C_CLOCK_DIVIDER_626) // 400Khz
            sprintf(buf, "current speed is 400kHz\n");
        else if (bsc_div == BCM2835_I2C_CLOCK_DIVIDER_150) // 1.7Mhz
            sprintf(buf, "current speed is 1.7MHz\n");
        else
            sprintf(buf, "current speed is invalid / unknown \n");

        printf(GRNSTR, buf);

        lp=0;
        do
        {
            printf(YLWSTR,"What is your new speed ?\n1: 100kHz, 2: 400kHz, 3: 1.7Mhz");
            printf(YLWSTR," (99 = return) ");
            scanf("%d",&div);

            lp=1;

            switch(div)
            {
            case 1 :
                bsc_div = BCM2835_I2C_CLOCK_DIVIDER_2500;
                break;
            case 2 :
                bsc_div = BCM2835_I2C_CLOCK_DIVIDER_626;
                break;
            case 3 :
                bsc_div = BCM2835_I2C_CLOCK_DIVIDER_150;
                printf(REDSTR,"Expect NACK errors due to restart-polling on BSC2835\n");
                break;
            case 99:
                return(0);
                break;
            default:
                sprintf(buf,"invalid entry: %d. Try again\n", div);
                printf(REDSTR, buf);
                lp=0;
                break;
            }
        } while (lp == 0);
    }

    // set divider
    bcm2835_i2c_setClockDivider(bsc_div);

    // display only interactive mode
    if (divider == 0){
        sprintf(buf,"divider set to %d\n", bsc_div);
        printf(GRNSTR, buf);
    }

    return(0);
}


/* setup hardware  */
void hw_init() {

    if (!bcm2835_init()) {
        printf(REDSTR,"Can't init bcm2835!\n");
        exit(1);
    }

    // will select I2C channel 0 or 1 depending on board reversion.
    if (!bcm2835_i2c_begin()){
        printf(REDSTR,"Can't setup i2c pin!\n");
        exit(1);
    }

    /* set BSC speed */
    if (set_divider(bsc_div)) close_out(1);

    /* set slave address for mcp23008*/
    if (set_slave(slave_address_base)) close_out(1);

    // reset mcp23008
    if (set_reset(reset_gpio))  close_out(1);
}


/* end the program correctly */
int close_out(int end){

    // if earlier child was created with earlier conf_int()
    if (ch_pid > 0)
    {
        // kill the earlier child process
        kill (ch_pid,SIGKILL);
    }

    // reset pins
    bcm2835_i2c_end();

    // release memory
    bcm2835_close();

    // if exit is requested
    if (end)    exit(end);
}


/* read some register(s) from MCP23008
 * @param reg : starting register to read
 * @param amount : #num of register to read sequential
 *
 * return value
 *  1 = error
 *  0 = OK
 */

read_reg(char reg, uint32_t count)
{

    if ((reg > 0x0a) || (reg < 0))
    {
        printf("invalid starting register\n");
        return(1);
    }

    if ((count+reg > 0x0b) || (count < 1))
    {
        printf("invalid amount registers to read requested\n");
        return(1);
    }

    // perform read with restart
    switch(bcm2835_i2c_read_register_rs(&reg, buf, count))
    {
        case BCM2835_I2C_REASON_ERROR_NACK :
            printf(REDSTR,"NACK error\n");
            return(1);
            break;
        case BCM2835_I2C_REASON_ERROR_CLKT :
            printf(REDSTR,"Clock stretch error\n");
            return(1);
            break;
        case BCM2835_I2C_REASON_ERROR_DATA :
            printf(REDSTR,"not all data has been read\n");
            return(1);
            break;
        case BCM2835_I2C_REASON_OK:
            return(0);
            break;
        default:
            printf(REDSTR,"unkown return code\n");
            return(1);
    }
}

/* read all the MCP23008 control registers into the buffer
 * return value
 *  1 = error
 *  0 = OK
 */

int read_all_reg()
{
    return(read_reg(0,11));
}

/* Display control registers and display info */
int disp_control(){

    int i,lp,tmp;

    printf(YLWSTR,"Display configuration and control registers\t\t\t\tvalue\n");

    // read MCP23008 registers
    if (read_all_reg()) return(1);

    for (i=0; i< 11; i++) {
        tmp = buf[i];

        switch(i)
        {
        case 0  : printf("IODIR\tIO7\tIO6\tIO5\tIO4\tIO3\tIO2\tIO1\tIO0\t:0x%x\n",tmp);

            for (lp=8;lp>0;lp--)
            {
                if (tmp & 0x80) printf(GRNSTR,"\tin");
                else printf(BLUSTR,"\tout");

                tmp<<= 1;
            }
            break;
        case 1  : printf("IPOL\tIP7\tIP6\tIP5\tIP4\tIP3\tIP2\tIP1\tIP0\t:0x%x\n",tmp);
            for (lp=8;lp>0;lp--)
            {
                if (tmp & 0x80) printf(GRNSTR,"\treverse");
                else printf(BLUSTR,"\tsame");

                tmp<<= 1;
            }
            break;
        case 2  : printf("GPINTEN\tGPINT7\tGPINT6\tGPINT5\tGPINT4\tGPINT3\tGPINT2\tGPINT1\tGPINT0\t:0x%x\n",tmp);
            for (lp=8;lp>0;lp--)
            {
                if (tmp & 0x80) printf(GRNSTR,"\tenable");
                else printf(BLUSTR,"\tdisable");

                tmp<<= 1;
            }
            break;
        case 3  : printf("DEFVAL\tDEF7\tDEF6\tDEF5\tDEF4\tDEF3\tDEF2\tDEF1\tDEF0\t:0x%x\n",tmp);
            for (lp=8;lp>0;lp--)
            {
                if (tmp & 0x80) printf(GRNSTR,"\tHIGH");
                else printf(BLUSTR,"\tLOW");

                tmp<<= 1;
            }
            break;
        case 4  : printf("INTCON\tIOC7\tIOC6\tIOC5\tIOC4\tIOC3\tIOC2\tIOC1\tIOC0\t:0x%x\n",tmp);
            for (lp=8;lp>0;lp--)
            {
                if (tmp & 0x80) printf(GRNSTR,"\tDEFVAL");
                else printf(BLUSTR,"\tlast");

                tmp<<= 1;
            }
            break;
        case 5  : printf("IOCON\tSEQOP\t\tDISSLW\t\tODR\t\tINTPOL\t\t:0x%x\n",tmp);
            for (lp=8;lp>0;lp--)
            {
                if (lp == 6){
                    if (tmp & 0x20) printf(GRNSTR,"\tdisabled\t");
                    else printf(BLUSTR,"\tenabled\t");
                }
                else if (lp == 5){
                    if (tmp & 0x10) printf(GRNSTR,"disabled");
                    else printf(BLUSTR,"\tenabled");
                }
                else if (lp == 3){
                    if (tmp & 0x4) printf(GRNSTR,"\tdisabled");
                    else printf(BLUSTR,"\t\tactive\t");
                }
                else if (lp == 2){
                    if (tmp & 0x2) printf(GRNSTR,"\tactive-high");
                    else printf(BLUSTR,"\tactive-low");
                }
            }
            break;
        case 6  : printf("GPPU\tPU7\tPU6\tPU5\tPU4\tPU3\tPU2\tPU1\tPU0\t:0x%x\n",tmp);
            for (lp=8;lp>0;lp--)
            {
                if (tmp & 0x80) printf(GRNSTR,"\tpull-up");
                else printf(BLUSTR,"\tfloat");

                tmp<<= 1;
            }
            break;
        case 7  : printf("INTF\tINT7\tINT6\tINT5\tINT4\tINT3\tINT2\tINT1\tINT0\t:0x%x\n",tmp);
            for (lp=8;lp>0;lp--)
            {
                if (tmp & 0x80) printf(GRNSTR,"\ttrigger");
                else printf(BLUSTR,"\tclear");

                tmp<<= 1;
            }
            break;
        case 8  : printf("INTCAP\tICP7\tICP6\tICP5\tICP4\tICP3\tICP2\tICP1\tICP0\t:0x%x\n",tmp);
            for (lp=8;lp>0;lp--)
            {
                if (tmp & 0x80) printf(GRNSTR,"\tHIGH");
                else printf(BLUSTR,"\tLOW");

                tmp<<= 1;
            }
            break;
        case 9  : printf("GPIO\tGP7\tGP6\tGP5\tGP4\tGP3\tGP2\tGP1\tGP0\t:0x%x\n",tmp);
            for (lp=8;lp>0;lp--)
            {
                if (tmp & 0x80) printf(GRNSTR,"\tHIGH");
                else printf(BLUSTR,"\tLOW");

                tmp<<= 1;
            }
            break;
        case 10 : printf("OLAT\tOL7\tOL6\tOL5\tOL4\tOL3\tOL2\tOL1\tOL0\t:0x%x\n",tmp);
            for (lp=8;lp>0;lp--)
            {
                if (tmp & 0x80) printf(GRNSTR,"\tHIGH");
                else printf(BLUSTR,"\tLOW");

                tmp<<= 1;
            }
            break;
        }
        printf("\n\n");
    }
}

/* write MCP23008 register
 * @param regaddr : register to write
 * @param val : value to write
 *
 * return :
 * 0 = OK
 * 1 = Error
 */

int write_reg(char regaddr, char val)
{
    char    buff[3];

    buff[0]=regaddr;
    buff[1]=val;

    switch(bcm2835_i2c_write(buff, 2))
    {
        case BCM2835_I2C_REASON_ERROR_NACK :
            printf(REDSTR,"write NACK error\n");
            return(1);
            break;
        case BCM2835_I2C_REASON_ERROR_CLKT :
            printf(REDSTR,"write Clock stretch error\n");
            return(1);
            break;
        case BCM2835_I2C_REASON_ERROR_DATA :
            printf(REDSTR,"write not all data has been sent\n");
            return(1);
            break;
        case BCM2835_I2C_REASON_OK:
            return(0);
            break;
    }
}

/* set or remove interrupt on MCP23008 pin */
int set_int()
{
    int     lp, gpio, dir, def=0, lev, intlev;
    char    val,filter=0;

    printf(YLWSTR,"set Interrupt\n");

    // read current control registers
    if (read_all_reg()) return(1);

    lp=0;
    do
    {
        printf(GRNSTR, "For which GPIO (0 - 7) do you want to change the interrupt? (99 = return) ");
        scanf("%d",&gpio);

        if (gpio == 99)   return(0);

        if ((gpio < 0) || (gpio > 7))   printf("Invalid gpio %d, retry\n", gpio);
        else  lp=1;

    } while (lp==0);

    lp=0;
    do
    {
        printf(GRNSTR,"Do you want to 1 = set or 2 = remove the interrupt? (99 = return) ");
        scanf("%d",&dir);

        if (dir == 99)   return(0);

        if ((dir != 1) && (dir != 2)) printf("Invalid selection %d, retry\n", dir);
        else  lp=1;
    } while (lp == 0);

    if (dir == 1)  // set
    {
        lp=0;
        do
        {
            printf(GRNSTR,"Do you want to compare against 1 = fixed value or 2 = any change?  (99 = return) ");
            scanf("%d",&lev);

            if (lev == 99)   return(0);

            if ((lev != 1) && (lev != 2)) printf("Invalid selection %d, retry\n", lev);
            else lp=1;
        } while (lp == 0);

        if (lev == 1)   // compare against fixed value
        {
            lp=0;
            do
            {
                printf(GRNSTR,"If the pin level is the OPPOSITE of the selection an interrupt occurs\n");
                printf(GRNSTR,"Do you want to compare against 1 = HIGH or 2 = LOW?  (99 = return) ");
                scanf("%d",&def);

                if (def == 99)   return(0);

                if ((def != 1) && (def != 2)) printf("Invalid selection %d, retry\n", def);
                else lp=1;
            } while (lp == 0);
        }

        lp=0;
        do
        {
            printf(GRNSTR,"Interrupt output polarity 1 = active-high 2 = active-low?  (99 = return) ");
            scanf("%d",&intlev);

            if (intlev == 99)   return(0);

            if ((intlev != 1) && (intlev != 2)) printf("Invalid selection %d, retry\n", intlev);
            else lp=1;
        } while (lp == 0);
    }

    // set filter
    filter = 1 << gpio;

    // set interrupt on GPIO
    if (dir == 1)
    {
        // set default compare value for pin
        if (def == 1) val = buf[DEFVAL] | filter;   // compare to high
        else val = buf[DEFVAL] & ~filter;           // compare to low
        write_reg(DEFVAL,val);

        // set interrupt control for pin
        if (lev == 1)  val = buf[INTCON] | filter;  // compare DEFVAL
        else           val = buf[INTCON] & ~filter;  // previous value
        write_reg(INTCON,val);

        // enable interupt pin
        if (intlev == 1) val = buf[IOCON] | 0x2;    // active-high
        else   val = buf[IOCON] & 0xd;              // active-low

        val = val & 0x0b;                           // NOT open drain
        write_reg(IOCON,val);

        // enable interrupt on pin
        val = buf[GPINTEN] | filter;
        write_reg(GPINTEN,val);
    }
    else    // remove interrupt from pin
    {
        val = buf[GPINTEN] & ~filter;
        write_reg(GPINTEN,val);

    }
}


/* set GPIO pin
 * input ( with or without pull-up)
 * output (Low or High)
 *
 */
int set_gpio()
{
    int     lp, gpio, dir, pu, lev, tmp;
    char    val,filter=0;

    printf(YLWSTR,"set GPIO\n");

    // read current control registers
    if (read_all_reg()) return(1);

    lp=0;
    do
    {
        printf(GRNSTR, "Which GPIO (0 - 7) do you want to set? (99 = return) ");
        scanf("%d",&gpio);

        if (gpio == 99)   return(0);

        if ((gpio < 0) || (gpio > 7))   printf("invalid gpio %d, retry\n", gpio);
        else  lp=1;

    } while (lp==0);

    lp=0;
    do
    {
        printf(GRNSTR,"Do you want to set as 1 = input or 2 = output? (99 = return) ");
        scanf("%d",&dir);

        if (dir == 99)   return(0);

        if ((dir != 1) && (dir != 2)) printf("invalid selection %d, retry\n", dir);
        else  lp=1;
    } while (lp == 0);

    lp=0;
    do
    {
        if (dir == 2)  // output
        {
            printf(GRNSTR,"Do you want to set 1 = HIGH or 2 = LOW?  (99 = return) ");
            scanf("%d",&lev);

            if (lev == 99)   return(0);

            if ((lev != 1) && (lev != 2)) printf("Invalid selection %d, retry\n", lev);
            else lp=1;
        }
        else    // input
        {
            printf(GRNSTR,"Do you want to set 1 = pull-up, 2 = NO pull-up?  (99 = return) ");
            scanf("%d",&pu);

            if (pu == 99)   return(0);

            if ((pu != 1) && (pu != 2)) printf("invalid selection %d, retry\n", pu);
            else lp=1;
        }

    } while (lp == 0);

    // set filter
    filter = 1 << gpio;

    // set GPIO as output
    if (dir == 2)
    {
        val = buf[IODIR] & ~filter;
        write_reg(IODIR,val);

        // set high ?
        if (lev == 1)  val = buf[OLAT] | filter;
        else           val = buf[OLAT] & ~filter;

        write_reg(OLAT,val);

    }
    else    // set as input
    {
        val = buf[IODIR] | filter;
        write_reg(IODIR,val);

        // set Pull-up?
        if (pu == 1)    val = buf[GPPU] | filter;
        else            val = buf[GPPU] & ~filter;

        write_reg(GPPU,val);
    }
}

/* configure the GPIO on the Raspberry to RECEIVE the interrupts from
 * MCP23008.
 * set pin
 * set to trigger on active HIGH or LOW
 * setup to call the routine to handle the interrupt
 */
void conf_int()
{
    int lp, tmp, det;

    do
    {
        printf(YLWSTR,"What is the Raspberry GPIO for interrupt from MCP23008? (99 = return) ");
        scanf("%d",&tmp);

        if (tmp == 99) return;

        if (tmp > 28)
        {
            printf(REDSTR, "Invalid entry, must be lower than 28. Try again\n");
        }
    } while (tmp > 28);

    int_gpio = tmp;

    // get detection (high or low)
    lp=0;
    do
    {
        printf(YLWSTR,"1 = active-high, 2 = active-low (99 = return) ");
        scanf("%d",&det);

        if (det == 99) return;

        if ((det == 1) || (det == 2))
            lp =1;
        else
            printf(REDSTR, "Invalid entry. Try again\n");

    } while (lp == 0);

    // if earlier child was created with earlier conf_int()
    if (ch_pid > 0)
    {
        // kill the earlier child process
        kill (ch_pid,SIGKILL);
    }

    // now create new child program to detect
    ch_pid = fork();

    if (ch_pid < 0)
    {
        printf(REDSTR,"could not create child process to handle interrupts\n");
        return;
    }
    // if parent:  save the PID and return
    else if (ch_pid > 0)
    {
        printf("child process to handle interrupt has been created (pid: %d\n", ch_pid);
        return;
    }

    /* for child process to execute */

    // read MCP23008 registers (clear any pending interrupt first by reading INTF/GPIO)
    if (read_all_reg()) return;

    // disable falling edge (just in case it was set earlier)
    bcm2835_gpio_clr_afen(int_gpio);

    // disable rising edge (just in case it was set earlier)
    bcm2835_gpio_clr_aren(int_gpio);

    // set as GPIO on Raspberry input
    bcm2835_gpio_fsel(int_gpio, BCM2835_GPIO_FSEL_INPT);

    if (det == 1)   // active-high
    {
        // add pull_down
        bcm2835_gpio_set_pud(int_gpio,BCM2835_GPIO_PUD_DOWN);

        // enable rising edge detection
        bcm2835_gpio_aren(int_gpio);
    }
    else
    {               // active-low
        // add pull_up
        bcm2835_gpio_set_pud(int_gpio,BCM2835_GPIO_PUD_UP);

        // enable falling edge detection
        bcm2835_gpio_afen(int_gpio);
    }

    while(1)
    {
        if (bcm2835_gpio_eds(int_gpio))
        {
            printf(GRNSTR,"\nInterrupt from MCP23008\n");

            // read MCP23008 registers
            if (read_all_reg()) return;

            // determine which pin on the MCP23008 caused the interrupt
            tmp = buf[INTF];

            printf(YLWSTR,"The interrupt was driven from the following GP on MCP23008:\n");

            for (lp=0;lp<8;lp++)
            {
                if (tmp & 0x01)
                {
                    printf("GP-%d ",lp);

                    // here you COULD start an action based on GP that caused interrupt
                    // e.g. if (lp == 1){......

                }

                // check next pin
                tmp >>= 1;
            }

            printf("\n");

            /* needed as Raspberry executes fast and can cause repeated interrupts
             * in case you have a switch that connect with ground + pull-up
             * you could check with read_reg(GPIO, 1) the value and loop untill
             * this changes to HIGH again (switch released) instead of a 2 seconds wait
             *
             * in case you compare against an fixed value, you can read GPIO and loop
             * untill the value is the same as the fixed value to compare before continuing
             */

            sleep(2);

            // clear the eds flag in Raspberry by setting it to 1
            bcm2835_gpio_set_eds(int_gpio);

            // Read MCP23008 registers (remove interrupt)
            // apparently one read is not enough given the bounch that can happen on the pin.
            if (read_all_reg()) return;
        }
    }
    printf("exit child\n");
}

/* read selective register(s) from MCP23008 */

int read_sel_reg()
{
    int lp, reg, count;

    lp=0;
    do
    {
        printf(YLWSTR,"provide starting register address (99 = return) ");
        scanf("%d",&reg);

        if (reg == 99) return(0);

        if((reg < 0) || (reg > 0x0a))
        {
            sprintf(buf,"invalid starting register address provided : %x\n", reg);
            printf(REDSTR, buf);
        }
        else
        {
            lp=1;
        }
    } while( lp == 0);


    lp=0;
    do
    {
        printf(YLWSTR,"How many registers do you want to read (99 = return) ");
        scanf("%d",&count);

        if (count == 99) return(0);

        if((count < 1) || (count > (11+count)))
        {
            sprintf(buf,"invalid starting register address provided : %x\n", count);
            printf(REDSTR, buf);
        }
        else
        {
            lp=1;
        }
    } while( lp == 0);

    if(read_reg(reg,count)) return(1);

    for (lp=0;lp<count; lp++)
    {
        printf("Content of register %d: hex 0x%x\n", lp, buf[lp]);
    }

    return(0);
}


int main(int argc, char *argv[])
{
    int tmp=0, disp=1;

    // do hardware init
    hw_init();

    // get manual input
    do
    {
        printf(YLWSTR,"\nWhat do you want to do ? \n\n");
        printf("1   change slave address (currently 0x%x)\n", slave_address_base);
        printf("2   change divider (currently dec: %d)\n", bsc_div);
        printf("3   change reset_gpio on Raspberry (currently %d)\n", reset_gpio);
        printf("4   set a GP pin on MCP23008\n");
        printf("5   set/reset interrupt on a GP pin of the MCP23008\n");
        printf("6   display the configuration and control registers MCP23008\n");
        printf("7   set/reset automatic display registers after option 1 - 5\n");
        printf("8   setup Raspberry to receive interrupt from MCP23008\n");
        printf("9   read selective register(s)from MCP23008\n");
        printf(YLWSTR, "\n99  exit program ");

        scanf("%d",&tmp);

        switch(tmp)
        {
        case 1:
            set_slave(0);
            if (disp == 1) disp_control();
            break;
        case 2:
            set_divider(0);
            if (disp == 1) disp_control();
            break;
        case 3:
            set_reset(0);
            if (disp == 1) disp_control();
            break;
        case 4:
            set_gpio();
            if (disp == 1) disp_control();
            break;
        case 5:
            set_int();
            if (disp == 1) disp_control();
            break;
        case 6:
            disp_control();
        case 7:
            disp = ~disp;
            break;
        case 8:
            conf_int();
            break;
        case 9:
            read_sel_reg();
            break;
        case 99:
            break;
        default:
            printf(REDSTR,"invalid entry, try again\n");
            break;
        }

    } while (tmp != 99);

    //close cleanly
    close_out(1);
}
